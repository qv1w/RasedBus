<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('buses', function (Blueprint $table) {
            // حذف الفهارس القديمة إذا كانت موجودة
            $table->dropIndex(['idx_buses_driver']);
            
            // إضافة Foreign Keys
            $table->foreign('driver_id', 'buses_driver_id_foreign')
                  ->references('id')
                  ->on('drivers')
                  ->onDelete('set null')
                  ->onUpdate('cascade');
            
            $table->foreign('assigned_center', 'buses_assigned_center_foreign')
                  ->references('center_name')
                  ->on('centers')
                  ->onDelete('set null')
                  ->onUpdate('cascade');
        });
    }

    public function down(): void
    {
        Schema::table('buses', function (Blueprint $table) {
            $table->dropForeign('buses_driver_id_foreign');
            $table->dropForeign('buses_assigned_center_foreign');
        });
    }
};