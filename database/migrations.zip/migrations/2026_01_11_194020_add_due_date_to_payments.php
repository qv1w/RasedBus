<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('payments', function (Blueprint $table) {
            // إضافة عمود تاريخ الاستحقاق إذا لم يكن موجوداً
            if (!Schema::hasColumn('payments', 'due_date')) {
                $table->date('due_date')->nullable()->after('payment_date');
            }
        });

        // تحديث القيم الموجودة
        // الدفعات التي ليس لها إيصال تصبح 'awaiting_receipt'
        \DB::table('payments')
            ->whereNull('receipt_image')
            ->where('status', 'pending')
            ->update(['status' => 'awaiting_receipt']);
    }

    public function down(): void
    {
        Schema::table('payments', function (Blueprint $table) {
            if (Schema::hasColumn('payments', 'due_date')) {
                $table->dropColumn('due_date');
            }
        });
    }
};