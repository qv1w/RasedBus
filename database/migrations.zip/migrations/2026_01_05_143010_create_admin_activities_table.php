<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('admin_activities', function (Blueprint $table) {
            $table->id();
            $table->foreignId('admin_id')->constrained('admins')->onDelete('cascade');
            $table->string('action'); // login, logout, approve_student, reject_student, add_student, edit_student, add_bus, etc.
            $table->string('description')->nullable();
            $table->string('model_type')->nullable(); // Student, Bus, Driver, etc.
            $table->unsignedBigInteger('model_id')->nullable();
            $table->string('ip_address')->nullable();
            $table->timestamps();
        });

        // إضافة حقل عدد مرات الدخول في جدول المديرين إذا لم يكن موجوداً
        if (!Schema::hasColumn('admins', 'login_count')) {
            Schema::table('admins', function (Blueprint $table) {
                $table->integer('login_count')->default(0)->after('status');
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('admin_activities');
        
        if (Schema::hasColumn('admins', 'login_count')) {
            Schema::table('admins', function (Blueprint $table) {
                $table->dropColumn('login_count');
            });
        }
    }
};