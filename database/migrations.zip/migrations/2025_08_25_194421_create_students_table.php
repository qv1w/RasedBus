<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('students', function (Blueprint $table) {
            $table->id();
            $table->string('student_id')->unique()->comment('رقم الطالبة');
            $table->string('name')->comment('الاسم الكامل');
            $table->string('email')->unique()->comment('البريد الإلكتروني');
            $table->string('national_id', 10)->unique()->comment('رقم الهوية الوطنية');
            $table->date('birthdate')->comment('تاريخ الميلاد');
            $table->string('mobile', 15)->comment('رقم الجوال');
            $table->text('address')->nullable()->comment('العنوان التفصيلي');
            $table->string('guardian_name')->comment('اسم ولي الأمر');
            $table->string('guardian_mobile', 15)->comment('جوال ولي الأمر');
            $table->enum('preferred_schedule', ['صباحية', 'مسائية'])->comment('الفترة المفضلة');
            $table->string('center')->nullable()->comment('المركز المسجلة به');
            $table->decimal('latitude', 10, 8)->nullable()->comment('خط العرض');
            $table->decimal('longitude', 11, 8)->nullable()->comment('خط الطول');
            $table->enum('status', ['pending', 'approved', 'rejected', 'suspended'])
                  ->default('pending')
                  ->comment('حالة الطلب');
            $table->unsignedBigInteger('assigned_bus_id')->nullable()->comment('الباص المخصص');
            $table->string('pickup_point')->nullable()->comment('نقطة الالتقاء');
            $table->time('pickup_time')->nullable()->comment('وقت الالتقاء');
            $table->decimal('total_paid', 10, 2)->default(0)->comment('إجمالي المبلغ المدفوع');
            $table->decimal('total_required', 10, 2)->default(500.00)->comment('إجمالي المبلغ المطلوب');
            $table->text('notes')->nullable()->comment('ملاحظات');
            $table->date('registration_date')->default(now())->comment('تاريخ التسجيل');
            $table->timestamps();
            
            $table->index('student_id', 'idx_student_id');
            $table->index('national_id', 'idx_national_id');
            $table->index('email', 'idx_email');
            $table->index('status', 'idx_status');
            $table->index('center', 'idx_center');
            $table->index('preferred_schedule', 'idx_schedule');
            $table->index('assigned_bus_id', 'idx_bus');
            $table->index('registration_date', 'idx_registration_date');
            
            $table->index(['status', 'center'], 'idx_status_center');
            $table->index(['center', 'preferred_schedule'], 'idx_center_schedule');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('students');
    }
};