<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('memorizations', function (Blueprint $table) {
            // إضافة الأعمدة المطلوبة
            $table->unsignedBigInteger('student_id')->after('id');
            $table->string('surah_name')->after('student_id');
            $table->integer('verses_memorized')->default(0)->after('surah_name');
            $table->date('memorization_date')->after('verses_memorized');
            $table->enum('grade', ['excellent', 'very_good', 'good', 'needs_improvement'])
                  ->default('good')->after('memorization_date');
            $table->enum('status', ['in_progress', 'completed', 'reviewed'])
                  ->default('in_progress')->after('grade');
            $table->text('notes')->nullable()->after('status');
            
            // إضافة foreign key
            $table->foreign('student_id')->references('id')->on('students')->onDelete('cascade');
            
            // إضافة indexes للأداء
            $table->index(['student_id', 'status']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('memorizations', function (Blueprint $table) {
            // حذف foreign key أولاً
            $table->dropForeign(['student_id']);
            
            // حذف الأعمدة
            $table->dropColumn([
                'student_id',
                'surah_name', 
                'verses_memorized',
                'memorization_date',
                'grade',
                'status',
                'notes'
            ]);
        });
    }
};