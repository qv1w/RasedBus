<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // إضافة العمود bus_id إذا لم يكن موجوداً
        if (!Schema::hasColumn('drivers', 'bus_id')) {
            Schema::table('drivers', function (Blueprint $table) {
                $table->unsignedBigInteger('bus_id')->nullable()->after('assigned_center');
                $table->foreign('bus_id')->references('id')->on('buses')->onDelete('set null');
            });
        }

        // إضافة الأعمدة الأخرى المفقودة إذا لم تكن موجودة
        Schema::table('drivers', function (Blueprint $table) {
            if (!Schema::hasColumn('drivers', 'driver_id')) {
                $table->string('driver_id')->unique()->after('id');
            }
            
            if (!Schema::hasColumn('drivers', 'email')) {
                $table->string('email')->nullable()->after('mobile');
            }
            
            if (!Schema::hasColumn('drivers', 'license_type')) {
                $table->string('license_type')->nullable()->after('license_expiry');
            }
            
            if (!Schema::hasColumn('drivers', 'experience_years')) {
                $table->integer('experience_years')->default(0)->after('license_type');
            }
            
            if (!Schema::hasColumn('drivers', 'address')) {
                $table->text('address')->nullable()->after('experience_years');
            }
            
            if (!Schema::hasColumn('drivers', 'emergency_contact')) {
                $table->string('emergency_contact')->nullable()->after('address');
            }
            
            if (!Schema::hasColumn('drivers', 'emergency_phone')) {
                $table->string('emergency_phone')->nullable()->after('emergency_contact');
            }
            
            if (!Schema::hasColumn('drivers', 'assigned_center')) {
                $table->string('assigned_center')->nullable()->after('emergency_phone');
            }
            
            if (!Schema::hasColumn('drivers', 'status')) {
                $table->enum('status', ['active', 'inactive', 'on_leave', 'terminated'])->default('active')->after('bus_id');
            }
            
            if (!Schema::hasColumn('drivers', 'hire_date')) {
                $table->date('hire_date')->nullable()->after('status');
            }
            
            if (!Schema::hasColumn('drivers', 'salary')) {
                $table->decimal('salary', 10, 2)->nullable()->after('hire_date');
            }
            
            if (!Schema::hasColumn('drivers', 'notes')) {
                $table->text('notes')->nullable()->after('salary');
            }
        });

        // إضافة فهارس للأداء
        Schema::table('drivers', function (Blueprint $table) {
            if (!Schema::hasIndex('drivers', 'drivers_status_index')) {
                $table->index('status');
            }
            
            if (!Schema::hasIndex('drivers', 'drivers_national_id_index')) {
                $table->index('national_id');
            }
            
            if (!Schema::hasIndex('drivers', 'drivers_license_number_index')) {
                $table->index('license_number');
            }
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('drivers', function (Blueprint $table) {
            // حذف المفتاح الخارجي أولاً
            $table->dropForeign(['bus_id']);
            
            // حذف الأعمدة
            $columns = [
                'bus_id', 'driver_id', 'email', 'license_type', 
                'experience_years', 'address', 'emergency_contact',
                'emergency_phone', 'assigned_center', 'status',
                'hire_date', 'salary', 'notes'
            ];
            
            foreach ($columns as $column) {
                if (Schema::hasColumn('drivers', $column)) {
                    $table->dropColumn($column);
                }
            }
            
            // حذف الفهارس
            $indexes = [
                'drivers_status_index',
                'drivers_national_id_index', 
                'drivers_license_number_index'
            ];
            
            foreach ($indexes as $index) {
                if (Schema::hasIndex('drivers', $index)) {
                    $table->dropIndex($index);
                }
            }
        });
    }
};