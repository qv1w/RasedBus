<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('centers', function (Blueprint $table) {
            $table->id();
            $table->string('center_name')->unique();
            $table->text('address')->nullable();
            $table->text('detailed_address')->nullable();
            $table->enum('status', ['active', 'inactive', 'maintenance'])->default('active');
            
            // الفترات
            $table->boolean('morning_available')->default(true);
            $table->time('morning_start')->nullable();
            $table->time('morning_end')->nullable();
            $table->boolean('evening_available')->default(true);
            $table->time('evening_start')->nullable();
            $table->time('evening_end')->nullable();
            
            // الموقع
            $table->decimal('latitude', 10, 8)->nullable();
            $table->decimal('longitude', 11, 8)->nullable();
            
            // النطاقات الجغرافية
            $table->json('coverage_area')->nullable();
            $table->json('morning_coverage_area')->nullable();
            $table->json('evening_coverage_area')->nullable();
            
            // الإحصائيات
            $table->integer('current_students')->default(0);
            $table->integer('bus_count')->default(0);
            
            $table->text('notes')->nullable();
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('centers');
    }
};