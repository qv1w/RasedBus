<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('buses', function (Blueprint $table) {
            $table->id();
            
            // معلومات الباص الأساسية
            $table->string('number', 50)->unique()->comment('رقم الباص الفريد');
            $table->string('plate_number', 20)->unique()->comment('رقم لوحة الباص');
            $table->string('model', 100)->comment('موديل ونوع الباص');
            $table->integer('capacity')->comment('السعة الكاملة للباص');
            
            // معلومات التخصيص - العلاقات
            $table->string('assigned_center')->nullable()->comment('المركز المخصص للباص');
            $table->unsignedBigInteger('driver_id')->nullable()->comment('معرف السائق المخصص');
            
            // معلومات التشغيل
            $table->integer('current_students')->default(0)->comment('عدد الطالبات الحاليات');
            $table->enum('status', ['active', 'inactive', 'maintenance'])->default('active')->comment('حالة الباص');
            
            // معلومات إضافية
            $table->text('notes')->nullable()->comment('ملاحظات إضافية');
            
            $table->timestamps();
            
            // ✅ Foreign Key للسائق فقط
            $table->foreign('driver_id')
                  ->references('id')
                  ->on('drivers')
                  ->onDelete('set null')
                  ->onUpdate('cascade');
            
         
            // الفهارس للبحث السريع
            $table->index('status');
            $table->index('assigned_center');
            $table->index('driver_id');
            $table->index(['status', 'assigned_center']);
            $table->index(['assigned_center', 'status', 'current_students']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('buses');
    }
};