<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('students', function (Blueprint $table) {
            $table->unsignedBigInteger('assigned_bus_id')->nullable()->after('center');
            
            $table->foreign('assigned_bus_id')
                  ->references('id')
                  ->on('buses')
                  ->onDelete('set null');
                  
            $table->index('assigned_bus_id');
        });
    }

    public function down(): void
    {
        Schema::table('students', function (Blueprint $table) {
            $table->dropForeign(['assigned_bus_id']);
            $table->dropColumn('assigned_bus_id');
        });
    }
};