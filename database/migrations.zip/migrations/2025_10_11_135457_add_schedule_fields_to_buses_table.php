<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::table('buses', function (Blueprint $table) {
            // إضافة الحقول الجديدة
            $table->enum('day', ['السبت', 'الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة'])
                  ->nullable()
                  ->after('capacity')
                  ->comment('يوم التشغيل');
            
            $table->enum('shift', ['صباحية', 'مسائية'])
                  ->nullable()
                  ->after('day')
                  ->comment('الفترة');
            
            $table->time('departure_time')
                  ->nullable()
                  ->after('shift')
                  ->comment('وقت المغادرة');
            
            $table->time('arrival_time')
                  ->nullable()
                  ->after('departure_time')
                  ->comment('وقت الوصول');
            
            // إضافة الفهارس
            $table->index('day');
            $table->index('shift');
            $table->index(['assigned_center', 'day', 'shift']);
        });
    }

    public function down()
    {
        Schema::table('buses', function (Blueprint $table) {
            $table->dropIndex(['assigned_center', 'day', 'shift']);
            $table->dropIndex(['shift']);
            $table->dropIndex(['day']);
            $table->dropColumn(['day', 'shift', 'departure_time', 'arrival_time']);
        });
    }
};