<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::table('admins', function (Blueprint $table) {
            if (!Schema::hasColumn('admins', 'phone')) {
                $table->string('phone')->nullable();
            }
            if (!Schema::hasColumn('admins', 'job_title')) {
                $table->string('job_title')->nullable();
            }
            if (!Schema::hasColumn('admins', 'bio')) {
                $table->text('bio')->nullable();
            }
            if (!Schema::hasColumn('admins', 'email_notifications')) {
                $table->boolean('email_notifications')->default(true);
            }
            if (!Schema::hasColumn('admins', 'sms_notifications')) {
                $table->boolean('sms_notifications')->default(false);
            }
            if (!Schema::hasColumn('admins', 'two_factor')) {
                $table->boolean('two_factor')->default(false);
            }
            if (!Schema::hasColumn('admins', 'language')) {
                $table->string('language')->default('ar');
            }
        });
    }

    public function down()
    {
        Schema::table('admins', function (Blueprint $table) {
            $table->dropColumn([
                'phone', 'job_title', 'bio', 
                'email_notifications', 'sms_notifications', 
                'two_factor', 'language'
            ]);
        });
    }
};