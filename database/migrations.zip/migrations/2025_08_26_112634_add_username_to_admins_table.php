<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
   public function up()
{
    Schema::table('admins', function (Blueprint $table) {
        if (!Schema::hasColumn('admins', 'username')) {
            $table->string('username')->unique()->after('name');
        }
        if (!Schema::hasColumn('admins', 'role')) {
            $table->string('role')->default('admin')->after('password');
        }
        if (!Schema::hasColumn('admins', 'status')) {
            $table->string('status')->default('active')->after('role');
        }
    });
}
};
