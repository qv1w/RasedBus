<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // التأكد من وجود جدول buses أولاً
        if (!Schema::hasTable('buses')) {
            Schema::create('buses', function (Blueprint $table) {
                $table->id();
                $table->string('number')->unique();
                $table->string('plate_number')->unique();
                $table->string('model')->nullable();
                $table->integer('capacity')->default(25);
                $table->integer('current_students')->default(0);
                $table->string('driver_name')->nullable();
                $table->string('driver_phone')->nullable();
                $table->string('assigned_center')->nullable();
                $table->enum('status', ['active', 'inactive', 'maintenance'])->default('active');
                $table->text('route')->nullable();
                $table->text('notes')->nullable();
                $table->timestamps();
                
                // فهارس
                $table->index('status');
                $table->index('assigned_center');
            });
        } else {
            // إضافة الأعمدة المفقودة إذا لم تكن موجودة
            Schema::table('buses', function (Blueprint $table) {
                if (!Schema::hasColumn('buses', 'number')) {
                    $table->string('number')->unique()->after('id');
                }
                
                if (!Schema::hasColumn('buses', 'plate_number')) {
                    $table->string('plate_number')->unique()->after('number');
                }
                
                if (!Schema::hasColumn('buses', 'model')) {
                    $table->string('model')->nullable()->after('plate_number');
                }
                
                if (!Schema::hasColumn('buses', 'capacity')) {
                    $table->integer('capacity')->default(25)->after('model');
                }
                
                if (!Schema::hasColumn('buses', 'current_students')) {
                    $table->integer('current_students')->default(0)->after('capacity');
                }
                
                if (!Schema::hasColumn('buses', 'driver_name')) {
                    $table->string('driver_name')->nullable()->after('current_students');
                }
                
                if (!Schema::hasColumn('buses', 'driver_phone')) {
                    $table->string('driver_phone')->nullable()->after('driver_name');
                }
                
                if (!Schema::hasColumn('buses', 'assigned_center')) {
                    $table->string('assigned_center')->nullable()->after('driver_phone');
                }
                
                if (!Schema::hasColumn('buses', 'status')) {
                    $table->enum('status', ['active', 'inactive', 'maintenance'])->default('active')->after('assigned_center');
                }
                
                if (!Schema::hasColumn('buses', 'route')) {
                    $table->text('route')->nullable()->after('status');
                }
                
                if (!Schema::hasColumn('buses', 'notes')) {
                    $table->text('notes')->nullable()->after('route');
                }
            });
            
            // إضافة فهارس للأداء
            Schema::table('buses', function (Blueprint $table) {
                if (!Schema::hasIndex('buses', 'buses_status_index')) {
                    $table->index('status');
                }
                
                if (!Schema::hasIndex('buses', 'buses_assigned_center_index')) {
                    $table->index('assigned_center');
                }
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('buses');
    }
};