<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('drivers', function (Blueprint $table) {
            $table->id();
            $table->string('driver_id')->unique()->comment('رقم السائق');
            $table->string('name')->comment('اسم السائق');
            $table->string('mobile', 15)->comment('رقم الجوال');
            $table->string('email')->nullable()->unique()->comment('البريد الإلكتروني');
            $table->text('address')->nullable()->comment('العنوان');
            $table->string('license_number')->unique()->comment('رقم الرخصة');
            $table->string('license_type')->nullable()->comment('نوع الرخصة');
            $table->enum('status', ['active', 'inactive', 'on_leave'])->default('active')->comment('الحالة');
            $table->text('notes')->nullable()->comment('ملاحظات');
            $table->integer('experience_years')->nullable()->comment('سنوات الخبرة');
            $table->string('emergency_contact')->nullable()->comment('جهة اتصال طوارئ');
            $table->string('emergency_phone', 15)->nullable()->comment('هاتف الطوارئ');
            $table->string('assigned_center')->nullable()->comment('المركز المخصص');
            $table->date('hire_date')->nullable()->comment('تاريخ التعيين');
            $table->decimal('salary', 10, 2)->nullable()->comment('الراتب');
            $table->timestamps();
            
            // Indexes
            $table->index('driver_id');
            $table->index('status');
            $table->index('assigned_center');
        });
    }

    public function down()
    {
        Schema::dropIfExists('drivers');
    }
};