<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * تشغيل المايجريشن
     */
    public function up(): void
    {
        // التحقق من وجود الجدول
        if (Schema::hasTable('centers')) {
            // إذا كان الجدول موجود، تحديث الأعمدة المطلوبة
            Schema::table('centers', function (Blueprint $table) {
                // إضافة العنوان التفصيلي إذا لم يكن موجوداً
                if (!Schema::hasColumn('centers', 'detailed_address')) {
                    $table->text('detailed_address')->nullable()->after('center_name');
                }
                
                // التأكد من وجود جميع الأعمدة المطلوبة
                if (!Schema::hasColumn('centers', 'center_name')) {
                    $table->string('center_name')->after('id');
                }
                
                if (!Schema::hasColumn('centers', 'latitude')) {
                    $table->decimal('latitude', 10, 8)->nullable()->after('detailed_address');
                }
                
                if (!Schema::hasColumn('centers', 'longitude')) {
                    $table->decimal('longitude', 11, 8)->nullable()->after('latitude');
                }
                
                if (!Schema::hasColumn('centers', 'status')) {
                    $table->enum('status', ['active', 'inactive'])->default('active')->after('longitude');
                }
                
                if (!Schema::hasColumn('centers', 'morning_available')) {
                    $table->boolean('morning_available')->default(false)->after('status');
                }
                
                if (!Schema::hasColumn('centers', 'morning_start')) {
                    $table->time('morning_start')->nullable()->after('morning_available');
                }
                
                if (!Schema::hasColumn('centers', 'morning_end')) {
                    $table->time('morning_end')->nullable()->after('morning_start');
                }
                
                if (!Schema::hasColumn('centers', 'evening_available')) {
                    $table->boolean('evening_available')->default(false)->after('morning_end');
                }
                
                if (!Schema::hasColumn('centers', 'evening_start')) {
                    $table->time('evening_start')->nullable()->after('evening_available');
                }
                
                if (!Schema::hasColumn('centers', 'evening_end')) {
                    $table->time('evening_end')->nullable()->after('evening_start');
                }
                
                if (!Schema::hasColumn('centers', 'coverage_area')) {
                    $table->json('coverage_area')->nullable()->after('evening_end');
                }
                
                if (!Schema::hasColumn('centers', 'morning_coverage_area')) {
                    $table->json('morning_coverage_area')->nullable()->after('coverage_area');
                }
                
                if (!Schema::hasColumn('centers', 'evening_coverage_area')) {
                    $table->json('evening_coverage_area')->nullable()->after('morning_coverage_area');
                }
                
                if (!Schema::hasColumn('centers', 'current_students')) {
                    $table->integer('current_students')->default(0)->after('evening_coverage_area');
                }
                
                if (!Schema::hasColumn('centers', 'bus_count')) {
                    $table->integer('bus_count')->default(0)->after('current_students');
                }
                
                if (!Schema::hasColumn('centers', 'notes')) {
                    $table->text('notes')->nullable()->after('bus_count');
                }
            });
        } else {
            // إنشاء الجدول من الصفر
            Schema::create('centers', function (Blueprint $table) {
                $table->id();
                $table->string('center_name')->comment('اسم المركز - ثابت');
                $table->text('detailed_address')->nullable()->comment('العنوان التفصيلي - قابل للتعديل');
                $table->decimal('latitude', 10, 8)->nullable()->comment('خط العرض');
                $table->decimal('longitude', 11, 8)->nullable()->comment('خط الطول');
                $table->enum('status', ['active', 'inactive'])->default('active')->comment('حالة المركز');
                
                // الفترات والمواعيد
                $table->boolean('morning_available')->default(false)->comment('تفعيل الفترة الصباحية');
                $table->time('morning_start')->nullable()->comment('بداية الفترة الصباحية');
                $table->time('morning_end')->nullable()->comment('نهاية الفترة الصباحية');
                $table->boolean('evening_available')->default(false)->comment('تفعيل الفترة المسائية');
                $table->time('evening_start')->nullable()->comment('بداية الفترة المسائية');
                $table->time('evening_end')->nullable()->comment('نهاية الفترة المسائية');
                
                // النطاقات الجغرافية
                $table->json('coverage_area')->nullable()->comment('النطاق الجغرافي العام');
                $table->json('morning_coverage_area')->nullable()->comment('النطاق الجغرافي الصباحي');
                $table->json('evening_coverage_area')->nullable()->comment('النطاق الجغرافي المسائي');
                
                // الإحصائيات
                $table->integer('current_students')->default(0)->comment('عدد الطالبات الحالي');
                $table->integer('bus_count')->default(0)->comment('عدد الباصات النشطة');
                
                // ملاحظات
                $table->text('notes')->nullable()->comment('ملاحظات إضافية');
                
                $table->timestamps();
                
                // فهارس
                $table->index('center_name');
                $table->index('status');
                $table->index(['morning_available', 'evening_available']);
                $table->index(['latitude', 'longitude']);
            });
        }
        
        // إزالة الأعمدة غير المرغوبة إذا كانت موجودة
        if (Schema::hasTable('centers')) {
            Schema::table('centers', function (Blueprint $table) {
                // إزالة عمود السعة إذا كان موجوداً
                if (Schema::hasColumn('centers', 'capacity')) {
                    $table->dropColumn('capacity');
                }
            });
        }
    }

    /**
     * التراجع عن المايجريشن
     */
    public function down(): void
    {
        // يمكن اختيار حذف الجدول أو تعديل الأعمدة حسب الحاجة
        Schema::dropIfExists('centers');
    }
};